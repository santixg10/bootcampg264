/* let edad = prompt("cuantos años tienes?");
alert("Tienes " + edad + "años");
console.log("El usuario dijo que tiene " + edad + " años"); */
let numero1;
let numero2;
let resultado;
/* concatena de esta manera 
numero1 = prompt("ingrese el numero 1: ");
numero2 = prompt("ingrese el numero 2: ");
resultado = numero1 + numero2
console.log(resultado)*/


/* numero1 = parseInt(prompt("ingrese el numero 1: "));
console.log(typeof numero1);
numero2 = parseInt(prompt("ingrese el numero 2: "));
console.log(typeof numero2);

resultado = numero1 + numero2
console.log(resultado)
alert("El resultado de la suma es: 😊 "+resultado);/* para emojis windows+punto 

resultado = numero1-numero2
console.log(resultado)
alert("El resultado de la resta es: 😂 "+resultado);

resultado = numero1*numero2
console.log(resultado)
alert("El resultado de la multiplicacion es: 👌 "+resultado);

resultado = numero1/numero2
console.log(resultado)
alert("El resultado de la division es: 😁 "+resultado); */

/* condicional if */

/* let temperatura =  parseFloat(prompt("ingrese la temperatura: "));

if(temperatura > 25){
    alert("Esta mas caliente  ")
}else if(temperatura >= 15){
    alert("Esta templado  ")
}else{
    alert("Esta haciendo frio ")
} */
Ejercicio1
/* let edad = prompt("Digite tu  edad😁")

if (edad > 55) {
    alert("eres un señor 👴")
} else if (edad >= 18) {
    alert("Eres un adulto 👨‍🦱")
} else if (edad <= 17 & edad >10) {
    alert("Eres adolecente 👌")
} else if (edad > 2 && edad <=10) {
    alert("eres un niño 👦")
}  else{
    alert("Eres un bebe 👶")
} */
    
/* for(let i = 10; i >= 1; i--){
    console.log(i);
} */
Ejercicio2
/* for (let i=2;i< 21;i+=2){
    console.log(i);
}  */
Ejercicio3
for (let i=1;i<=50;i++){
    if(i % 2 == 0){
        console.log("el número "+i+ " es par")
    }else {
        console.log("el número "+i+ " es impar")
    }
}